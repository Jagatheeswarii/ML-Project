
from flask import Flask, escape, request, render_template
App =Flask(__name__,template_folder='templates/')
import pickle
import numpy as np
App = Flask(__name__)
model = pickle.load(open( r'university.pkl', 'rb'))
@App.route('/',methods=['GET',])
def home():
    return render_template("Demo2.html")
@App.route('/' ,methods=['GET','POST']) 
def predict():

    min1=[290.0, 92.0, 1.0, 1.0,1,0 ,6.8,0.0]
    max1=[340.0, 120.0, 5.0, 5.0, 5.0,9.92, 1.0]
    k= [float(x) for x in request.form.values()]
    p=[]    
    for i in range(7):
        l=(k[i]-min1[i])/(max1[i]-min1[i])
        p.append(l)
    prediction=model.predict([p])
    print(prediction)
    output=prediction
    if(output==True):
        
        return render_template("noChance.html", Prediction_text="You Dont Have a chance of getting admission")
    else:
       
        return render_template('Chance.html',Prediction_text='You  Have a chance of getting admission')
  
if __name__ == "__main__":
    App.run(host='0.0.0.0',port=80,debug=True)



